void ADC_Init() {
    ADCON1 = 0x07;  // Set all ports to digital while AN7 is analog for the sharp IR sensor
    ADCON0 = 0b01110101;  // Enabeling ADC
    TRISC |= 0x08;  //set RC3 as input
}


unsigned int ADC_Read() {
    ADCON0 &= 0xC7;
    ADCON0 |= 0x38;
    ADCON0 |= 0x04;  //start  conversion
    while(ADCON0 & 0x04);  //complete conversion
    return ((ADRESH << 8) + ADRESL);  //return to main result
}


void init() {
    TRISC &= 0xFC;  //set RC0 and RC1 as outputs
    PORTC = 0x00;  // turn off all pins on port C
    ADC_Init();    // call for initializing ADC
}


void startMotor() {
    PORTC |= 0x01;  //motor works  at port RC0
}

void stopMotor() {
    PORTC &= 0xFE;  //motorstopss  at port RC0
}


void activateBuzzer() {
    PORTC |= 0x02;  // buzzer on at port RC1
}

void deactivateBuzzer() {
    PORTC &= 0xFD;  //buzzer off at port RC1
}

void main() {
    init();  // set all ports in the main

    while (1) {
        if (PORTB & 0x02) {                             // Check if the push button is pressed
            while (PORTB & 0x02);

            while (1) {
                if (!(PORTB & 0x01)) {  // Digital IR sensor outputs zero when it detects movement(not 1)
                    stopMotor();
                    activateBuzzer();
                    while (!(PORTB & 0x01));  //  no movement
                    deactivateBuzzer();
                } else {

                    unsigned int adcValue = ADC_Read();  //read  value from the analog IR sensor and put it in adcvalue
                    if (adcValue > 512) {
                     char i =0;
                      startMotor();
                        for(i;i<255;i++){}  //delay

                    } else {
                        stopMotor();  //Stop if no grass
                    }
                }
            }
        }
    }
}